const Express = require("express")
const con = require("./dbb");
const app = Express();
const cors = require('cors')
app.use(cors());


app.get("/getpatient", (req, res) => {
  con.query("select * from users", function (err, result) {
    if (err) {
      res.send("error")
    } else {
      res.send(result)
    }
  })
})

app.get("/getpatient/search/:id", (req, res) => {
  let id = req.params.id;
  con.query("select * from users where id=?", [id], function (err, result) {
    if (err) {
      res.send("error")
    } else {
      res.send(result)
    }
  })
})
// get api for login to patient

app.get("/login/:number/:password",(req,res)=>{
  let number=req.params.number;
  let password=req.params.password;
  con.query("select * from users where mobileno=? and pass=?",[number,password],function(err,result){
    if(err){
      res.send("error")
    }else{
      res.send(result)
      return result;
    }
  })
})


app.delete("/deletepatientdata/:id",(req,res)=>{
    const delid=req.params.id;
    con.query('delete from users where id=?',[delid],function (err,result) {
        if(err)
        {
            console.log(err)
        }
        else{
            res.send("deleted")
            console.log(result)
        }
    })
})








const bodyParser = require('body-parser');
app.use(bodyParser.json());
app.use(bodyParser.urlencoded({ extended: true }));

app.post('/postpatient', (req, res) => {
    const id = req.body.id;
  const firstname = req.body.firstname;
  const lastname = req.body.lastname;
  const mobileno = req.body. mobileno;
  const gender = req.body.gender;
  const dob = req.body.dob;
  const pass=req.body.pass;
  const bg=req.body.bg;

  con.query('insert into users (id, firstname, lastname,mobileno,gender,dob,pass,bg) values(?,?,?,?,?,?,?,?)', [id, firstname, lastname,mobileno,gender,dob,pass,bg], (err, result) => {
    if (err) {
      console.log(err);
    } else {
      res.send(result);
    }
  })
})
// doctor data


app.get("/getdoctor", (req, res) => {
  con.query("select * from dregi", function (err, result) {
    if (err) {
      res.send("error")
    } else {
      res.send(result)
    }
  })
})

app.get("/getdoctor/search/:id", (req, res) => {
  let id = req.params.id;
  con.query("select * from dregi where id=?", [id], function (err, result) {
    if (err) {
      res.send("error")
    } else {
      res.send(result)
    }
  })
})
app.delete("/deletedoctordata/:id",(req,res)=>{
    const delid=req.params.id;
    con.query('delete from dregi where id=?',[delid],function (err,result) {
        if(err)
        {
            console.log(err)
        }
        else{
            res.send("deleted")
            console.log(result)
        }
    })
})

app.post('/postdoctor', (req, res) => {
    const id = req.body.id;
  const firstname = req.body.firstname;
  const lastname = req.body.lastname;
  const mobileno = req.body. mobileno;
  const email = req.body.email;
  const degreename = req.body.degreename;
  const universityname=req.body.universityname;
  const speciallization=req.body.speciallization;
  const graduationyear = req.body.graduationyear;
  const licenseno = req.body.licenseno;
  const licencopy = req.body.licencopy;
  const image = req.body.image;
  const clinicname=req.body.clinicname;
  const buildingdetails=req.body.buildingdetails;
  const landmark = req.body.landmark;
  const street = req.body.street;
  const state=req.body.state;
  const dist=req.body.dist;
  const city = req.body.city;
  const pincode = req.body.pincode;
  const cliniccontactno=req.body.cliniccontactno;
  const pass=req.body.pass;



  con.query('insert into dregi values(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)', [id, firstname, lastname,mobileno,email,degreename,universityname,speciallization,graduationyear,licenseno,licencopy,image,clinicname,buildingdetails,landmark,street,state,dist,city,pincode,cliniccontactno,pass], (err, result) => {
    if (err) {
      console.log(err);
    } else {
      res.send(result);
    }
  })
})

// patient login

app.get("/getpatientlogin", (req, res) => {
  con.query("select * from palogin", function (err, result) {
    if (err) {
      res.send("error")
    } else {
      res.send(result)
    }
  })
})

app.get("/getpatientlogin/search/:id", (req, res) => {
  let id = req.params.id;
  con.query("select * from palogin where id=?", [id], function (err, result) {
    if (err) {
      res.send("error")
    } else {
      res.send(result)
    }
  })
})
app.delete("/deletepatientlogin/:id",(req,res)=>{
    const delid=req.params.id;
    con.query('delete from palogin where id=?',[delid],function (err,result) {
        if(err)
        {
            console.log(err)
        }
        else{
            res.send("deleted")
            console.log(result)
        }
    })
})

app.post('/postpatientlogin', (req, res) => {
  const id=req.body.id;
  const mobileno = req.body.mobileno;
  const pass = req.body.pass;
  

  con.query('insert into palogin  values(?,?,?)', [id, mobileno,pass], (err, result) => {
    if (err) {
      console.log(err);
    } else {
      res.send(result);
    }
  })
})

// Dr.Login

app.get("/getdoctorlogin", (req, res) => {
  con.query("select * from drlogin", function (err, result) {
    if (err) {
      res.send("error")
    } else {
      res.send(result)
    }
  })
})

app.get("/getdoctor/search/:id", (req, res) => {
  let id = req.params.id;
  con.query("select * from drlogin where id=?", [id], function (err, result) {
    if (err) {
      res.send("error")
    } else {
      res.send(result)
    }
  })
})
app.delete("/deletedoctordata/:id",(req,res)=>{
    const delid=req.params.id;
    con.query('delete from drlogin where id=?',[delid],function (err,result) {
        if(err)
        {
            console.log(err)
        }
        else{
            res.send("deleted")
            console.log(result)
        }
    })
})

app.post('/postdoctorlogin', (req, res) => {
  const id = req.body.id;
const email = req.body.mobileno;
const pass = req.body.pass;


con.query('insert into drlogin  values(?,?,?)', [id, email,pass], (err, result) => {
  if (err) {
    console.log(err);
  } else {
    res.send(result);
  }
})
})



app.get("/getpatientlogin/search/:mobileno/:pass", (req, res) => {
  let mobileno = req.params.mobileno;
  let pass = req.params.pass;
  con.query("select * from users where mobileno=? and pass=?", [mobileno,pass], function (err, result) {
    if (err) {
      res.send("error")
    } else {
      res.send(result)
    }
  })
})

app.get("/getdoctorlogin/search/:mobileno/:pass", (req, res) => {
  let mobileno = req.params.mobileno;
  let pass = req.params.pass;
  con.query("select * from dregi where mobileno=? and pass=?", [mobileno,pass], function (err, result) {
    if (err) {
      res.send("error")
    } else {
      res.send(result)
    }
  })
})

// dr.time sloat

app.get("/getdrslot", (req, res) => {
  con.query("select * from drtimeslot", function (err, result) {
    if (err) {
      res.send("error")
    } else {
      res.send(result)
    }
  })
})

app.get("/getdrslot/search/:id", (req, res) => {
  let id = req.params.id;
  con.query("select * from drtimeslot where id=?", [id], function (err, result) {
    if (err) {
      res.send("error")
    } else {
      res.send(result)
    }
  })
})

app.delete("/deletedrslot/:id",(req,res)=>{
  const delid=req.params.id;
  con.query('delete from drtimeslot where id=?',[delid],function (err,result) {
      if(err)
      {
          console.log(err)
      }
      else{
          res.send("deleted")
          console.log(result)
      }
  })
})

app.post('/postdrslot', (req, res) => {
  const id = req.body.id;
const slot_date = req.body.slot_date;
const start_time = req.body.start_time;
const end_time = req.body. end_time;



con.query('insert into drtimeslottt (id ,slot_date,start_time,end_time) values(?,?,?,?)', [id, slot_date,start_time,end_time], (err, result) => {
  if (err) {
    console.log(err);
  } else {
    res.send(result);
  }
})
})

// appoitment

app.get("/getappoitment", (req, res) => {
  con.query("select * from papp", function (err, result) {
    if (err) {
      res.send("error")
    } else {
      res.send(result)
    }
  })
})

app.get("/getappoitment/search/:id", (req, res) => {
  let id = req.params.id;
  con.query("select * from papp where id=?", [id], function (err, result) {
    if (err) {
      res.send("error")
    } else {
      res.send(result)
    }
  })
})

app.post('/postappoitment', (req, res) => {
  const id = req.body.id;
const sr_no = req.body.sr_no;
const datee = req.body.datee;
const timee = req.body. time;
const contactno = req.body. contactno;




con.query('insert into papp (id ,sr_no,datee,timee,contactno) values(?,?,?,?,?)', [id,sr_no,datee,timee,contactno], (err, result) => {
  if (err) {
    console.log(err);
  } else {
    res.send(result);
  }
})
})







app.listen(5000, (err) => {
  if (err) {
    console.log(err);
  } else {
    console.log("on port 5000")
  }
})