const express=require("express")
const mysql = require("mysql")
const app=express()
const cors =require("cors")
app.use(cors())

// app.use(express.json())

var con = mysql.createConnection({
  host: "localhost",
  user: "root",
  password: "India@11",
  database: 'patientdata'
});
con.connect((err)=>{
    if(err)
    {
        console.log(err)
    }
    else{
        console.log("CONNECTED")
    }
})